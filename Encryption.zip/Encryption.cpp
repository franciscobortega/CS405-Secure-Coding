// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Francisco Ortega
// SNHU | CS 405 - Secure Coding
// Ahlam Alhweiti

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    const auto key_length = key.length();
    const auto source_length = source.length();

    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    for (size_t i = 0; i < source_length; ++i)
    {
        // Apply XOR transformation to source char with the key char
        output[i] = source[i] ^ key[i % key_length];
    }

    assert(output.length() == source_length);

    return output;
}

std::string read_file(const std::string& filename)
{
    std::string file_text;

    try
    {
        std::string line;
        std::ifstream readFile(filename, std::ios::in | std::ios::binary);
        if (readFile.is_open())
        {
            // loop through each line in the file 
            while (std::getline(readFile, line))
            {
                // add back newline character (stripped by getline)
                line.push_back('\n');
                // add the current line to file_text
                file_text += line;
            }

            readFile.close();
        }
    }
    catch (...) {
        std::cout << "Failed to read file!" << std::endl;
    }

    return file_text;
}

std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    size_t pos = string_data.find('\n');
    
    if (pos != std::string::npos)
    { 
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    try
    {
        std::ofstream writeFile(filename, std::ios::out | std::ios::binary);
        if (writeFile.is_open())
        {
            // write the student name
            writeFile << student_name << '\n';

            // create and write the timestamp in (yyyy-mm-dd) format
            char timestamp_buffer[20];
            std::tm time_data;
            time_t time_now = time(0);
            localtime_s(&time_data, &time_now);
            std::strftime(timestamp_buffer, 20, "%Y-%m-%d", &time_data);
            
            writeFile << timestamp_buffer << '\n';

            // write the key used
            writeFile << key << '\n';

            // write the data
            writeFile << data;

            writeFile.close();
        }
    }
    catch (...) {
        std::cout << "Failed to write file!" << std::endl;
    }
}

int main()
{
    std::cout << "Encyption Decryption Test!" << std::endl;

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrytpteddatafile.txt";
    const std::string source_string = read_file(file_name);
    const std::string key = "XMarksTheXOR";

    const std::string student_name = get_student_name(source_string);

    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;

}
