// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Francisco Ortega
// SNHU CS 405
// Ahlam Alhweiti

#include <iostream>

// A custom exception derived from std::exception
// simply overrides the what() function with our custom message
// Reference: https://www.geeksforgeeks.org/how-to-throw-custom-exception-in-cpp/
class custom_exception : public std::exception
{
public:
    const char* what() const throw()
    {
        return "CustomException thrown!";
    }
};

bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    throw std::exception("StandardException: Thrown from do_even_more_custom_application_logic!");

    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;
    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e)
    {
        std::cout << "Caught exception from do_custom_application_logic - " << e.what() << std::endl;
    }

    throw custom_exception();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

// Reference for exceptions: https://learn.saylor.org/mod/book/view.php?id=33103&chapterid=13302
float divide(float num, float den)
{
    if (den == 0)
    {
        throw std::overflow_error("OverflowError: Cannot divide by 0!");
    }

    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;
    try 
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::overflow_error& e)
    {
        std::cout << "Caught exception from do_division - " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const custom_exception& e)
    {
        std::cout << "Caught custom exception from main - " << e.what() << std::endl;
    }
    catch (const std::exception& e)
    {
        std::cout << "Caught standard exception from main - " << e.what() << std::endl;
    }
    catch (...)
    {
        std::cout << "Uncaught exception from main!" << std::endl;
    }

    return 0;
}